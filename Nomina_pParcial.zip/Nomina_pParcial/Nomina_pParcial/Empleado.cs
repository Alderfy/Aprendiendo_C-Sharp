﻿using System;

namespace Nomina_pParcial
{
    public class Empleado
    {
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public string Cedula { get; set; }
        public double sueldoBruto { get; set; }
    }
}
